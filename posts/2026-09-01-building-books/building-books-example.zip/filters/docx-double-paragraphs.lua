local function para_is_empty(para)
  return #para.content == 0
end

local function para_contains_structural_inline(para)
  for _, inline in ipairs(para.content) do
    if inline.t == "Image" or inline.t == "Note" then
      return true
    end
  end
  return false
end

local function should_double_space_para(para)
  return not para_is_empty(para) and not para_contains_structural_inline(para)
end

local function spacer_para()
  -- Pandoc's DOCX writer drops truly empty paragraphs, so use a single
  -- non-breaking space to force Word to keep a visually blank paragraph.
  return pandoc.Para({ pandoc.Str("\u{00A0}") })
end

local function expand_blocks(blocks)
  local expanded = {}

  for _, block in ipairs(blocks) do
    if block.t == "Div" then
      block.content = expand_blocks(block.content)
      table.insert(expanded, block)
    else
      table.insert(expanded, block)

      if block.t == "Para" and should_double_space_para(block) then
        table.insert(expanded, spacer_para())
      end
    end
  end

  return expanded
end

function Pandoc(doc)
  doc.blocks = expand_blocks(doc.blocks)
  return doc
end
