---
title: "Lorem Ipsum"
---

# Lorem Ipsum

This short chapter is also a small Markdown guide. Write ordinary paragraphs with a blank line between them. For emphasis, use *italics*; for stronger emphasis, use **bold**. You can combine them as ***bold italics***.

## A chapter heading

Use `##` for a second-level heading and `###` for a smaller heading. Headings help readers to navigate the table of contents in the EPUB.

### A quiet moment

> “You came back,” Elena said.
>
> “I said I would,” Mara replied.

The `>` character creates a quotation. It can be useful for an epigraph, a letter, or a piece of remembered dialogue.

## An image

Put image files in the `assets` folder and refer to them with a relative path:

![A small heart illustration](assets/sample-heart.svg)

Pandoc includes this image in the EPUB when it builds the book.

## A simple table

| Character | What they want | What they hide |
| --- | --- | --- |
| Elena | A fresh start | She has read the old letters. |
| Mara | One honest conversation | She never stopped waiting. |

## Notes and links

A footnote gives a reader an extra detail without interrupting the scene.[^1]

For a fuller guide to the Markdown understood by this build, read the [Pandoc Markdown tutorial](https://pandoc.org/MANUAL.html#pandocs-markdown). This is also the normal Markdown form for a web link.

[^1]: Footnotes appear at the end of the chapter or in the reader's footnote view, depending on the EPUB application.
